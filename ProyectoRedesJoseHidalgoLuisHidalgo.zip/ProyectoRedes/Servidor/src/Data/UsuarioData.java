/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data;


import Domain.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;


public class UsuarioData {
   public void guardar(Usuario usuario) throws SQLException, ClassNotFoundException{
      try{
          Connection conexion = Conexion.obtener();
          PreparedStatement consulta;
       
            consulta = conexion.prepareStatement("INSERT INTO usuario (nombre, contrasena, rutaArchivo) VALUES(?, ?, ?)");
           // consulta.setInt(1, 0);
            consulta.setString(1, usuario.getNombre());
            consulta.setString(2, usuario.getContrasena());
            consulta.setString(3, usuario.getRutaArchivo());
     /*
            consulta = conexion.prepareStatement("UPDATE " + this.tabla + " SET titulo = ?, descripcion = ?, nivel_de_prioridad = ? WHERE id_tarea = ?");
            consulta.setString(1, usuario.getTitulo());
            consulta.setString(2, usuario.getDescripcion());
            consulta.setInt(3, usuario.getNivel_de_prioridad());
            consulta.setInt(4, usuario.getId_tarea());
       */
         consulta.executeUpdate();
        // Conexion.cerrar();
          JOptionPane.showMessageDialog(null, "Registrado correctamente");
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
   }
   public boolean existeNombre(String nombre) throws SQLException, ClassNotFoundException {
      try{
         Connection conexion = Conexion.obtener();
         PreparedStatement consulta = conexion.prepareStatement("SELECT * FROM usuario WHERE nombre = ?" );
         consulta.setString(1, nombre);
         ResultSet resultado = consulta.executeQuery();
         while(resultado.next()){
              //Conexion.cerrar();
            return true;
         }
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
       //Conexion.cerrar();
      return false;
   }
   
     public Usuario existeUsuario(String nombre, String contrasena) throws SQLException, ClassNotFoundException {
         Usuario usuario;
       try{
         Connection conexion = Conexion.obtener();
         PreparedStatement consulta = conexion.prepareStatement("SELECT nombre,contrasena,rutaArchivo FROM usuario WHERE nombre = ? and  contrasena = ?" );
         consulta.setString(1, nombre);
         consulta.setString(2, contrasena);
         ResultSet resultado = consulta.executeQuery();
        
         while(resultado.next()){
             usuario = new Usuario(resultado.getString("nombre"), resultado.getString("contrasena"), resultado.getString("rutaArchivo"));
          return usuario;
         }
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
       //Conexion.cerrar();
       usuario = new Usuario("", "", "");
      return usuario;
   }
   /*
   public void eliminar(Connection conexion, Tarea tarea) throws SQLException{
      try{
         PreparedStatement consulta = conexion.prepareStatement("DELETE FROM " + this.tabla + " WHERE id_tarea = ?");
         consulta.setInt(1, tarea.getId_tarea());
         consulta.executeUpdate();
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
   }
   public List<Tarea> recuperarTodas(Connection conexion) throws SQLException{
      List<Tarea> tareas = new ArrayList<>();
      try{
         PreparedStatement consulta = conexion.prepareStatement("SELECT id_tarea, titulo, descripcion, nivel_de_prioridad FROM " + this.tabla + " ORDER BY nivel_de_prioridad");
         ResultSet resultado = consulta.executeQuery();
         while(resultado.next()){
            tareas.add(new Tarea(resultado.getInt("id_tarea"), resultado.getString("titulo"), resultado.getString("descripcion"), resultado.getInt("nivel_de_prioridad")));
         }
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
      return tareas;
   }*/
}
