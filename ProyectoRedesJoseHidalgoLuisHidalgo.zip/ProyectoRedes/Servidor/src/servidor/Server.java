/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor;

import Domain.FTPServer;
import GUI.IpServer;
import GUI.VentanaPrincipal;
import java.io.DataInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;
import static javax.swing.JFrame.EXIT_ON_CLOSE;

/**
 *
 * @author 0jose
 */
public class Server  {

    /**
     * @param args the command line arguments
     */
     
    public static void main(String[] args) {
        IpServer ip = new IpServer();
        ip.setVisible(true);
        
        /*FTPServer server = new FTPServer(8081, 500, InetAddress.getByName("localhost"));
        server.init();
        VentanaPrincipal ventanaPrincipal = new VentanaPrincipal();
        ventanaPrincipal.setVisible(true);*/
      
  
    }
    
  
}