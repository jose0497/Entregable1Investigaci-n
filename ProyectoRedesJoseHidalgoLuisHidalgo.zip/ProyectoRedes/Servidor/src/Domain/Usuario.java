/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Domain;

/**
 *
 * @author 0jose
 */
public class Usuario {

    private String nombre;
    private String contrasena;
    private String rutaArchivo;
  

    public Usuario() {
    }

    public Usuario(String nombre, String contrasena, String rutaArchivo) {
        this.nombre = nombre;
        this.contrasena = contrasena;
        this.rutaArchivo = rutaArchivo;
    
    }
    
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public String getRutaArchivo() {
        return rutaArchivo;
    }

    public void setRutaArchivo(String rutaArchivo) {
        this.rutaArchivo = rutaArchivo;
    }
    
    
}
