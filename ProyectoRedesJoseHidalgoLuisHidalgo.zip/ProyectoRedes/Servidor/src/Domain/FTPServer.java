/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Domain;

import Data.UsuarioData;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.StringReader;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Files;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author 0jose
 *
 */
public class FTPServer extends ServerSocket implements Runnable {

    private Socket socket;

    private UsuarioData usuarioData;
    public static final int DEFAULT_BUFFER_SIZE = 1024 * 16;
    private static DataInputStream dataInputStream;

    public FTPServer(int port, int backlog, InetAddress bindAddr)
            throws IOException {
        super(port, backlog, bindAddr);
        usuarioData = new UsuarioData();
        System.out.println(">Server started on port: " + port);
    }

    public void init() {
        new Thread(this).start();
    }

    private class Connection extends Thread {

        public static final int DEFAULT_BUFFER_SIZE = 1024 * 16;
        //private BufferedReader receive;
        //private PrintStream send;
        private DataInputStream dis;
        private DataOutputStream dos;
        private DataInputStream dataInputStream;
        private BufferedInputStream bufferedInputStream;
        private Socket socket;
        private String rutaArchivo;

        /////////////////////////cliente
        private DataOutputStream dataOutputStreamC;
        private FileInputStream fileInputStreamC;
        private DataOutputStream dosC;
        private DataOutputStream dos2C;
        private DataInputStream disC;
        private DataInputStream dataInputStreamC;

        public Connection(Socket socket) {
            try {
                this.socket = socket;
                dataInputStream = new DataInputStream(socket.getInputStream());
                bufferedInputStream = new BufferedInputStream(socket.getInputStream());
                dis = new DataInputStream(socket.getInputStream());
                dos = new DataOutputStream(socket.getOutputStream());

                ////////cliente
                dataOutputStreamC = new DataOutputStream(socket.getOutputStream());
                dataInputStreamC = new DataInputStream(socket.getInputStream());
                //bufferedOutputStreamC = new BufferedOutputStream(outputStream);
                dosC = new DataOutputStream(socket.getOutputStream());
                dos2C = new DataOutputStream(socket.getOutputStream());
                disC = new DataInputStream(socket.getInputStream());

            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public void enviarMensaje(String mensaje) {
            try {
                this.dos.writeUTF(mensaje);
            } catch (IOException ex) {
                Logger.getLogger(FTPServer.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        public String leerMensaje() {
            try {

                return this.dis.readUTF();
                //return this.receive.readLine();
            } catch (IOException ex) {
                Logger.getLogger(FTPServer.class.getName()).log(Level.SEVERE, null, ex);
            }
            return null;
        }

        public int upFile(File file) {
            if (file.exists() && file.length() > 0) {
                try {
                    fileInputStreamC = new FileInputStream(file);
                    dataOutputStreamC.writeUTF(file.getName());
                    System.out.println("size" + file.length());
                    return (int) file.length();
                    //dataOutputStream.flush();
                    //new Thread(this).start();
                } catch (IOException ex) {
                    System.out.println("exeption");
                }
            }
            return 0;
        }

        private void notificaAccionesNuevas() throws IOException {

            try {

                String sentence = dis.readUTF();
                System.out.println("que llega: " + sentence);
                switch (sentence) {
                    case "existeUsuario":  //enviarArchivo
                        String nombre = leerMensaje();
                        String contrasena = leerMensaje();
                        System.out.println(nombre + contrasena);
                        Usuario usuario = new Usuario();

                        usuario = usuarioData.existeUsuario(nombre, contrasena);
                        System.out.println(usuario.getNombre());
                        rutaArchivo = usuario.getRutaArchivo();

                        if (!usuario.getNombre().equals("")) {
                            enviarMensaje("si");
                        } else {
                            enviarMensaje("no");
                        }
                        break;
                    case "enviarArchivo":

                        enviarMensaje("enviarArchivo");
                        //  System.out.println(this.leerMensaje());

                        //bandera = 1;
                        break;

                    case "archivo":
                        String fileName = dataInputStream.readUTF();
                        System.out.println(">>Receiving file: " + fileName);
                        System.out.println(">>Please wait...");
                        FileOutputStream fileOutputStream = new FileOutputStream(rutaArchivo + "\\" + fileName);
                        //int fileSize = (int) Files.size(new File(rutaArchivo + "\\" + fileName).toPath());
                        //  System.out.println(fileSize);
                        int tamano = Integer.parseInt(dataInputStream.readUTF());
                        //BufferedInputStream bis = new BufferedInputStream(dataInputStream);
                        //int res = IOUtils.copy(dataInputStream, fileOutputStream);
                        BufferedOutputStream bos = new BufferedOutputStream(fileOutputStream);
                        byte b[] = new byte[tamano + 10000];
                        for (int i = 0; i < b.length; i++) {

                            b[i] = (byte) dis.read();
                            //System.out.println(b[i]);
                            // bufferedInputStream.read(b);
                        }
                        bos.write(b);
                        fileOutputStream.close();
                        dos.flush();
                        // bos.flush();
                        /*
                        byte b[] = new byte[49];//DEFAULT_BUFFER_SIZE
                        int len = 0,
                         off = 0;

                        int count;
                        while ((count = dataInputStream.read(b)) >= 0) {
                            fileOutputStream.write(b, 0, count);
                        }*/

                        //fileOutputStream.flush();
                        //fileOutputStream.close();
                        //dataInputStream.close();
                        System.out.println(">>Task completed!");
                        enviarMensaje("Enviado corectamente");
                        break;
                    case "enviarNombreArchivos":
                        File carpeta = new File(rutaArchivo);
                        String[] listado = carpeta.list();
                        enviarMensaje("tamanoLista");
                        enviarMensaje(String.valueOf(listado.length));
                        if (listado == null || listado.length == 0) {
                            System.out.println("No hay elementos dentro de la carpeta actual");
                            return;
                        } else {
                            for (int i = 0; i < listado.length; i++) {
                                enviarMensaje(listado[i]);
                            }
                        }
                        break;
                    case "enviarArchivoACliente":
                        String rutaFinal = dataInputStream.readUTF();
                        enviarMensaje("archivoACliente");
                        System.out.println(rutaFinal);
                        File file = new File(rutaArchivo+"\\" + rutaFinal);
                        
                       // long tamanioArchivo = fileInputStreamC.getChannel().size();
                        fileInputStreamC = new FileInputStream(file);
                        dataOutputStreamC.writeUTF(file.getName());
                        System.out.println("sizewweewwweee" + file.length());
                        int tamanioArchivo = (int)file.length();
                      //  System.out.println(tamanioArchivo);
                        enviarMensaje(String.valueOf((int) tamanioArchivo));
                        //BufferedInputStream bis = new BufferedInputStream(dataInputStream);
                        //int res = IOUtils.copy(dataInputStream, fileOutputStream);
                        BufferedInputStream bis = new BufferedInputStream(fileInputStreamC);

                        byte b2[] = new byte[(int) tamanioArchivo + 10000];
                        bis.read(b2);
                        for (int j = 0; j < b2.length; j++) {
                            //  b[i] = (byte)bis.read();
                            //System.out.println(b[j]);
                            dos2C.write(b2[j]);
                        }

                        fileInputStreamC.close();
                        dos2C.flush();
                        System.out.println("Se envia al cliente");
                        /*   byte b[] = new byte[0];//DEFAULT_BUFFER_SIZE
                        int len = 0,
                         off = 0;
                        while ((len = fileInputStream.read(b)) > 0) {
                            System.out.println("cliente scribe");
                            dataOutputStream.write(b, off, len);
                        }
                        System.out.println("sale1");
                        dataOutputStream.flush();
                        //dataOutputStream.close();
                        // dataInputStream.close();
                        fileInputStream.close();
                        //Thread.sleep(3000);
                        System.out.println("sale");
                        //shutdown = true;*/
                        // JOptionPane.showMessageDialog(null, dataInputStream.readUTF());
                        break;
                    default:
                        break;
                }
            } catch (SQLException ex) {
                Logger.getLogger(FTPServer.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(FTPServer.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

        @Override
        public void run() {

            try {
                while (true) {
                    this.notificaAccionesNuevas();
                }
            } catch (IOException e) {
                e.printStackTrace();

            } finally {
                try {
                    socket.close();
                } catch (IOException ex) {
                    System.out.println("E. cliente se sale");
                }

            }
        }

    }

    @Override
    public void run() {
        System.out.println(">Waiting for connections...");
        Socket socket = null;
        while (true) {
            try {
                socket = accept();
                System.out.println(">>New Connection Received: " + socket.getInetAddress());
                System.out.println(">>Starting thread for connection...");
                Connection connection = new Connection(socket);
                connection.start();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}

/*
public class FTPServer extends ServerSocket implements Runnable {

    private boolean running = false;
    private String rutaArchivo = "";
    private PrintStream send;
    private BufferedReader receive;
    private UsuarioData usuarioData;

    public FTPServer(int port, int backlog, InetAddress bindAddr) throws IOException {
        super(port, backlog, bindAddr);
        running = true;
        System.out.println(">El server corre en el puerto: " + port);
    }

    public void init() {
        new Thread(this).start();
    }

    

        public static final int DEFAULT_BUFFER_SIZE = 1024 * 16;

        private DataInputStream dataInputStream;
        private Socket socket;

        public Connection(Socket socket) {
            try {
                this.socket = socket;
                dataInputStream = new DataInputStream(socket.getInputStream());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public void enviarMensaje(String mensaje) {
            send.println(mensaje);
        }

        public String leerMensaje() {
            try {

                //return this.input.readUTF();
                return receive.readLine();
            } catch (IOException ex) {
                Logger.getLogger(FTPServer.class.getName()).log(Level.SEVERE, null, ex);
            }
            return null;
        }

        @Override
        public void run() {
            try {
                String sentence = this.leerMensaje();
                switch (sentence) {
                    case "enviarArchivo":
                        String fileName = dataInputStream.readUTF();
                        System.out.println(">>Archivo que resive el server: " + fileName);
                        System.out.println(">>Porfavor espere...");
                        FileOutputStream fileOutputStream = new FileOutputStream(
                                "C:\\Users\\LUIS HIDALGO\\Documents\\LuisUCR\\Redes\\ProyectoRedes\\Servidor\\todosArchivos\\" + fileName);//ruta de la carpeta
                        byte b[] = new byte[DEFAULT_BUFFER_SIZE];
                        int len = 0,
                         off = 0;

                        int count;
                        while ((count = dataInputStream.read(b)) > 0) {
                            fileOutputStream.write(b, 0, count);
                        }
                        //fileOutputStream.flush();
                        fileOutputStream.close();
                        dataInputStream.close();
                        System.out.println(">>Tarea completa!");
                        break;
                    case "existeUsuario":    
                        String aux = leerMensaje();
                        System.out.println(aux);
                        if (usuarioData.existeNombre(aux)) {
                            enviarMensaje("si");
                        } else {
                            enviarMensaje("no");
                        }
                        break;
                }

            } catch (IOException e) {
                e.printStackTrace();
            } catch (SQLException ex) {
                Logger.getLogger(FTPServer.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(FTPServer.class.getName()).log(Level.SEVERE, null, ex);
            } finally {
                try {
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public boolean isRunning() {
        return running;
    }

}
 */
