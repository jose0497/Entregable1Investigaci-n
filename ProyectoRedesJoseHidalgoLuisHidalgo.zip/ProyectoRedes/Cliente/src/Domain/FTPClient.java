/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Domain;

import GUI.ArchivosServidor;
import GUI.SubirArchivo;
import GUI.VentanaPrincipal;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.StringReader;
import java.net.InetAddress;
import java.net.Socket;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author LUIS HIDALGO
 */
public class FTPClient extends Socket implements Runnable {

    private static Socket socket;
    private static DataOutputStream send;
    private static DataInputStream receive;
    public static final int DEFAULT_BUFFER_SIZE = 1024;
    private DataOutputStream dataOutputStream;
    private FileInputStream fileInputStream;
    private static DataOutputStream dos;
    private static DataOutputStream dos2;
    private static DataInputStream dis;
    private DataInputStream dataInputStream;
    private BufferedOutputStream bufferedOutputStream;

    ///////////////server
    private DataInputStream disS;
    private DataOutputStream dosS;
    private DataInputStream dataInputStreamS;
    private BufferedInputStream bufferedInputStreamS;

    private String rutaArchivo;

    public FTPClient(String ip) throws IOException {
        super(ip, 8081);
        try {

            initStreams(getInputStream(), getOutputStream());
        } catch (IOException ex) {
            Logger.getLogger(FTPClient.class.getName()).log(Level.SEVERE, null, ex);
        }
        new Thread(this).start();

    }

    static {
        // InetAddress address = InetAddress.getByName();//ip
        //socket = new Socket("localhost", 8081);//"192.168.43.182"    "localhost"address
        // send = new DataOutputStream(socket.getOutputStream());
        // this.address = InetAddress.getByName(ipServidor);
        //receive = new DataInputStream(socket.getInputStream());
    }

    public void initStreams(InputStream inputStream, OutputStream outputStream) {

        dataOutputStream = new DataOutputStream(outputStream);
        dataInputStream = new DataInputStream(inputStream);
        bufferedOutputStream = new BufferedOutputStream(outputStream);
        dos = new DataOutputStream(outputStream);
        dos2 = new DataOutputStream(outputStream);
        dis = new DataInputStream(inputStream);
        ///server
        dataInputStreamS = new DataInputStream(inputStream);
        bufferedInputStreamS = new BufferedInputStream(inputStream);
        disS = new DataInputStream(inputStream);
        dosS = new DataOutputStream(outputStream);

    }

    public static void enviarMensaje(String message) {

        try {
            FTPClient.dos.writeUTF(message);
        } catch (IOException ex) {
            Logger.getLogger(FTPClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static String leerMensaje() {
        try {

            return FTPClient.dis.readUTF();

        } catch (IOException ex) {
            Logger.getLogger(FTPClient.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public static void closeSocket() {
        Thread.interrupted();
    }

    public void upFile(File file) {
        if (file.exists() && file.length() > 0) {
            try {
                fileInputStream = new FileInputStream(file);
                dataOutputStream.writeUTF(file.getName());
                
                //dataOutputStream.flush();
                //new Thread(this).start();
            } catch (IOException ex) {
                Logger.getLogger(FTPClient.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    int i = 1;
    volatile boolean shutdown = false;

    @Override
    public void run() {
        while (i == 1) {
            try {
                String mensajeServidor = dataInputStream.readUTF();
                System.out.println("llega del serve: " + mensajeServidor);
                switch (mensajeServidor) {
                    case "si":

                        VentanaPrincipal ventanaPrincipal = new VentanaPrincipal();
                        ventanaPrincipal.setVisible(true);

                        break;
                    case "no":
                        JOptionPane.showMessageDialog(null, "El usuario no existe");
                        break;
                    case "enviarArchivo":
                        FTPClient.enviarMensaje("archivo");
                        System.out.println("Ruta: " + SubirArchivo.obtenerInstancia().getRutaArchivo());
                        upFile(new File(SubirArchivo.obtenerInstancia().getRutaArchivo()));
                        long tamanioArchivo = SubirArchivo.obtenerInstancia().getTamanioArchivo();

                        System.out.println(tamanioArchivo);
                        FTPClient.enviarMensaje(String.valueOf((int) tamanioArchivo));
                        //BufferedInputStream bis = new BufferedInputStream(dataInputStream);
                        //int res = IOUtils.copy(dataInputStream, fileOutputStream);
                        BufferedInputStream bis = new BufferedInputStream(fileInputStream);
                        byte b[] = new byte[(int) tamanioArchivo + 10000];
                        bis.read(b);
                        for (int j = 0; j < b.length; j++) {
                            //  b[i] = (byte)bis.read();
                            //System.out.println(b[j]);
                            dos2.write(b[j]);
                        }

                        fileInputStream.close();
                        dos2.flush();

               
                        JOptionPane.showMessageDialog(null, dataInputStream.readUTF());
                        break;
                    case "tamanoLista":
                        int tamano = Integer.parseInt(dataInputStream.readUTF());

                        ArrayList<String> listaArchivos = new ArrayList<>();
                        for (int j = 0; j < tamano; j++) {
                            listaArchivos.add(dataInputStream.readUTF().toString());
                            System.out.println("taman000o: " + tamano);
                            // System.out.println("Archivos de la lista: " + listaArchivos.get(j));
                        }
                        Thread.sleep(1000);
                        ArchivosServidor.obtenerInstancia().llenarTable(listaArchivos);

                        break;
                    case "archivoACliente":
                        String fileName = dataInputStreamS.readUTF();
                        System.out.println(">>Receiving file: " + fileName);
                        System.out.println(">>Please wait...");
                        FileOutputStream fileOutputStream = new FileOutputStream(fileName);
                        //int fileSize = (int) Files.size(new File(rutaArchivo + "\\" + fileName).toPath());
                        //  System.out.println(fileSize);
                        int tamano2 = Integer.parseInt(dataInputStreamS.readUTF());
                        //BufferedInputStream bis = new BufferedInputStream(dataInputStream);
                        //int res = IOUtils.copy(dataInputStream, fileOutputStream);
                        BufferedOutputStream bos = new BufferedOutputStream(fileOutputStream);
                        byte b2[] = new byte[tamano2 + 10000];
                        for (int k = 0; k < b2.length; k++) {

                            b2[k] = (byte) dis.read();
                            //System.out.println(b[i]);
                            // bufferedInputStream.read(b);
                        }
                        bos.write(b2);
                        fileOutputStream.close();
                        dosS.flush();

                        System.out.println(">>Task completed Client!");
                        //enviarMensaje("Enviado corectamente");
                        JOptionPane.showMessageDialog(null, "Descargado en la ruta del programa");
                        break;
                    default:
                        break;

                }
            } catch (IOException ex) {
                try {
                    initStreams(getInputStream(), getOutputStream());
                } catch (IOException ex2) {
                    Logger.getLogger(FTPClient.class.getName()).log(Level.INFO, null, ex2);
                }
            } catch (InterruptedException ex) {
                System.out.println("hola2");
            }

        }
    }

}

/*
public class FTPClient extends Socket implements Runnable {

    public static final int DEFAULT_BUFFER_SIZE = 1024;
    private DataOutputStream dataOutputStream;
    private FileInputStream fileInputStream;
    private static PrintStream send;
    private static BufferedReader receive;

    public FTPClient(InetAddress address, int port) throws IOException {
        super(address, port);
        initStreams(getInputStream(), getOutputStream());
    }

    public static void enviarMensaje(String message) {
        FTPClient.send.println(message);
    }

    public static String leerMensaje() {
        try {

            return FTPClient.receive.readLine();

        } catch (IOException ex) {
            Logger.getLogger(FTPClient.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public void initStreams(InputStream inputStream, OutputStream outputStream) {
        dataOutputStream = new DataOutputStream(outputStream);
    }

    public void upFile(File file) {
        if (file.exists() && file.length() > 0) {
            try {
                fileInputStream = new FileInputStream(file);
                dataOutputStream.writeUTF(file.getName());
                dataOutputStream.flush();
                new Thread(this).start();
            } catch (IOException ex) {
                Logger.getLogger(FTPClient.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void run() {
        while (true) {
            try {
                String mensajeServidor = receive.readLine();
                switch (mensajeServidor) {
                   
                    case "enviarArchivo":
                        byte b[] = new byte[DEFAULT_BUFFER_SIZE];
                        int len = 0,
                                off = 0;
                        
                        while ((len = fileInputStream.read(b)) > 0) {
                            dataOutputStream.write(b, off, len);
                        }
                        dataOutputStream.flush();
                        break;
                     default:
                        break;
                }
            } catch (IOException ex) {
                Logger.getLogger(FTPClient.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

    }
}
 */
