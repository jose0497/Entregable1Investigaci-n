/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

import Domain.FTPClient;
import GUI.IniciarSesion;
import GUI.VentanaPrincipal;
import GUI.ip;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author LUIS HIDALGO
 */
public class Client  {

    public static void main(String[] args) {
        // new FTPClient(InetAddress.getByName("127.0.0.1"), 8081).upFile(new File("C:\\Users\\LUIS HIDALGO\\Desktop\\img.jpeg"));
        ip ip = new ip();
        ip.setVisible(true);
        /*IniciarSesion iniciarSesion = new IniciarSesion();
        iniciarSesion.setVisible(true);*/
        //new FTPClient();
        // myClient.start();

    }

  
}
